import { Box, Center } from '@chakra-ui/react';
import React from 'react';
import ReactPlayer from 'react-player';

const VideoPlayer = ({ url }) => {
    return (
        <Box>
            <Center>
                <Box as="article" textAlign="center" padding={8} width="100%">
                    <ReactPlayer url={url} controls={true} width="100%" height="450px" />
                </Box>
            </Center>
        </Box>
    );
}

export default VideoPlayer;
