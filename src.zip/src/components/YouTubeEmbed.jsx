import { Box } from '@chakra-ui/react';
import React from 'react';

const YouTubeEmbed = ({ url }) => {
  // Extract the video ID from the YouTube URL
  const videoId = url.split('v=')[1];
  const embedUrl = `https://www.youtube.com/embed/${videoId}`;

  return (
    <Box position="relative" width="100%">
      <iframe
        title="YouTube video player"
        width="100%"
        height="438"
        src={embedUrl}
        allowFullScreen
      ></iframe>
    </Box>
  );
};

export default YouTubeEmbed;
