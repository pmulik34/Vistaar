import { Box, Center, Text, Button } from '@chakra-ui/react';
import React from 'react';

const ExternalLink = ({ url }) => {
    return (
        <Box>
            <Center>
                <Box mb={20} textAlign="center" mt={30} width="100%">
                    <Text>
                        Explore this content from an external website. Choose how you'd like to view it:
                    </Text>
                    <iframe
                        src={url}
                        title="External Website"
                        style={{
                            width: '100%',
                            height: '500px',
                            border: '1px solid #ccc',
                            padding: '10px',
                            borderRadius: '5px',
                            marginTop: '10px'
                        }}
                    ></iframe>
                    <Button
                        marginTop={1}
                        size="md"
                        className='custom-button'
                        style={{ width: "150px", marginTop: "10px" }}
                        onClick={() => window.open(url, '_blank')}
                    >
                        Open in New Tab
                    </Button>
                </Box>
            </Center>
        </Box>
    );
}

export default ExternalLink;
