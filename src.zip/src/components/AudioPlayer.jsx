import { Box, Center } from '@chakra-ui/react';
import React from 'react';

const AudioPlayer = ({ src }) => {
    return (
        <Center>
            <Box>
                <audio controls>
                    <source src={src} type="audio/mpeg" />
                    Your browser does not support the audio element.
                </audio>
            </Box>
        </Center>
    );
};

export default AudioPlayer;
