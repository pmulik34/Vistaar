import { Box, Button } from '@chakra-ui/react'
import React from 'react'

const PDFViewer = ({ src }) => {
  return (
    <Box display="flex" justifyContent="center" alignItems="center" height="100vh">
      <Box textAlign="center">
        <Box mb={4}>
          <embed src={src} width="1000" height="400" type='application/pdf' />
        </Box>
        <Button className='custom-button' as="a" href={src} target="_blank" rel="noopener noreferrer" mt={4} mb={4}>
          Open PDF in New Tab
        </Button>
      </Box>
    </Box>
  )
}

export default PDFViewer
